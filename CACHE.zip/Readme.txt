<2021 2학기 컴퓨터 구조 캐시 미니 프로젝트>
팀원 : 서동은, 주민영
<담당>
파일 입출력 : 주민영
캐시 코드 : 서동은
보고서 작성 : 주민영

<내용>
Direct mapped cache, 2 - way set associative cache, Fully associative cache 구현하고

각 input 데이터에 대해 hit or miss를 판단
-> cache update
-> hit ratio 및 bandwidth 계산